# fdk-aac-ios
fdk-aac build script for ios

1. ./autogen.sh
2. ./build_ios_xcode6.sh
